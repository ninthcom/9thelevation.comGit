// Minified version of jQuery Easing: http://gsgd.co.uk/sandbox/jquery/easing/
jQuery.easing["jswing"]=jQuery.easing["swing"];jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(a,b,c,d,e){return jQuery.easing[jQuery.easing.def](a,b,c,d,e)},easeInQuad:function(a,b,c,d,e){return d*(b/=e)*b+c},easeOutQuad:function(a,b,c,d,e){return-d*(b/=e)*(b-2)+c},easeInOutQuad:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b+c;return-d/2*(--b*(b-2)-1)+c},easeInCubic:function(a,b,c,d,e){return d*(b/=e)*b*b+c},easeOutCubic:function(a,b,c,d,e){return d*((b=b/e-1)*b*b+1)+c},easeInOutCubic:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b+c;return d/2*((b-=2)*b*b+2)+c},easeInQuart:function(a,b,c,d,e){return d*(b/=e)*b*b*b+c},easeOutQuart:function(a,b,c,d,e){return-d*((b=b/e-1)*b*b*b-1)+c},easeInOutQuart:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b*b+c;return-d/2*((b-=2)*b*b*b-2)+c},easeInQuint:function(a,b,c,d,e){return d*(b/=e)*b*b*b*b+c},easeOutQuint:function(a,b,c,d,e){return d*((b=b/e-1)*b*b*b*b+1)+c},easeInOutQuint:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b*b*b+c;return d/2*((b-=2)*b*b*b*b+2)+c},easeInSine:function(a,b,c,d,e){return-d*Math.cos(b/e*(Math.PI/2))+d+c},easeOutSine:function(a,b,c,d,e){return d*Math.sin(b/e*(Math.PI/2))+c},easeInOutSine:function(a,b,c,d,e){return-d/2*(Math.cos(Math.PI*b/e)-1)+c},easeInExpo:function(a,b,c,d,e){return b==0?c:d*Math.pow(2,10*(b/e-1))+c},easeOutExpo:function(a,b,c,d,e){return b==e?c+d:d*(-Math.pow(2,-10*b/e)+1)+c},easeInOutExpo:function(a,b,c,d,e){if(b==0)return c;if(b==e)return c+d;if((b/=e/2)<1)return d/2*Math.pow(2,10*(b-1))+c;return d/2*(-Math.pow(2,-10*--b)+2)+c},easeInCirc:function(a,b,c,d,e){return-d*(Math.sqrt(1-(b/=e)*b)-1)+c},easeOutCirc:function(a,b,c,d,e){return d*Math.sqrt(1-(b=b/e-1)*b)+c},easeInOutCirc:function(a,b,c,d,e){if((b/=e/2)<1)return-d/2*(Math.sqrt(1-b*b)-1)+c;return d/2*(Math.sqrt(1-(b-=2)*b)+1)+c},easeInElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e)==1)return c+d;if(!g)g=e*.3;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return-(h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g))+c},easeOutElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e)==1)return c+d;if(!g)g=e*.3;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return h*Math.pow(2,-10*b)*Math.sin((b*e-f)*2*Math.PI/g)+d+c},easeInOutElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e/2)==2)return c+d;if(!g)g=e*.3*1.5;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);if(b<1)return-.5*h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)+c;return h*Math.pow(2,-10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)*.5+d+c},easeInBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;return d*(b/=e)*b*((f+1)*b-f)+c},easeOutBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;return d*((b=b/e-1)*b*((f+1)*b+f)+1)+c},easeInOutBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;if((b/=e/2)<1)return d/2*b*b*(((f*=1.525)+1)*b-f)+c;return d/2*((b-=2)*b*(((f*=1.525)+1)*b+f)+2)+c},easeInBounce:function(a,b,c,d,e){return d-jQuery.easing.easeOutBounce(a,e-b,0,d,e)+c},easeOutBounce:function(a,b,c,d,e){if((b/=e)<1/2.75){return d*7.5625*b*b+c}else if(b<2/2.75){return d*(7.5625*(b-=1.5/2.75)*b+.75)+c}else if(b<2.5/2.75){return d*(7.5625*(b-=2.25/2.75)*b+.9375)+c}else{return d*(7.5625*(b-=2.625/2.75)*b+.984375)+c}},easeInOutBounce:function(a,b,c,d,e){if(b<e/2)return jQuery.easing.easeInBounce(a,b*2,0,d,e)*.5+c;return jQuery.easing.easeOutBounce(a,b*2-e,0,d,e)*.5+d*.5+c}});

// Minified version of FitVid.js
(function(a){a.fn.fitVids=function(b){var c={customSelector:null};var e=document.createElement("div"),d=document.getElementsByTagName("base")[0]||document.getElementsByTagName("script")[0];e.className="fit-vids-style";e.innerHTML="&shy;<style>               .fluid-width-video-wrapper {                 width: 100%;                              position: relative;                       padding: 0;                            }                                                                                   .fluid-width-video-wrapper iframe,        .fluid-width-video-wrapper object,        .fluid-width-video-wrapper embed {           position: absolute;                       top: 0;                                   left: 0;                                  width: 100%;                              height: 100%;                          }                                       </style>";d.parentNode.insertBefore(e,d);if(b){a.extend(c,b)}return this.each(function(){var f=["iframe[src^='http://player.vimeo.com']","iframe[src^='http://www.youtube.com']","iframe[src^='http://www.kickstarter.com']","object","embed"];if(c.customSelector){f.push(c.customSelector)}var g=a(this).find(f.join(","));g.each(function(){var k=a(this);if(this.tagName.toLowerCase()=="embed"&&k.parent("object").length||k.parent(".fluid-width-video-wrapper").length){return}var h=this.tagName.toLowerCase()=="object"?k.attr("height"):k.height(),i=h/k.width();if(!k.attr("id")){var j="fitvid"+Math.floor(Math.random()*999999);k.attr("id",j)}k.wrap('<div class="fluid-width-video-wrapper"></div>').parent(".fluid-width-video-wrapper").css("padding-top",(i*100)+"%");k.removeAttr("height").removeAttr("width")})})}})(jQuery);

//	Enables the use of console logging (through log('whatever') without breaking IE
window.log = function() {
  log.history = log.history || [];
  log.history.push(arguments);
  arguments.callee = arguments.callee.caller;  
  if(this.console) console.log( Array.prototype.slice.call(arguments) );
};
(function(b){function c(){}for(var d="assert,count,debug,dir,dirxml,error,exception,group,groupCollapsed,groupEnd,info,log,markTimeline,profile,profileEnd,time,timeEnd,trace,warn".split(","),a;a=d.pop();)b[a]=b[a]||c})(window.console=window.console||{});

/*
 *****************************************
 * MODELS
 *****************************************
 */
var NewsModel = Backbone.Model.extend({
	defaults: {
		'id': 			0,
		'cell_title': 		'',
		'slug':	'',
		'opened': 		false,
		'opentext': 	'Text',
		'closetext':	'Text'
	}
});

var ArtistModel = Backbone.Model.extend({
	defaults: {
		'id': 			0,
		'layout':		'',
		'resizeto':		false,
		'bigimg':		'',
		'normalimg':	'',
		'cell_title': 		'',
		'date':			'',
		//'playtime':		'',
		//'scene': 		'',
		//'website': 		'',
		'videos': 		false,
		'slug':			'',
		'permalink': 	'',
		//'likes': 		'',
		//'likedByUser': 	false,
		'opened':		false,
		'opentext':		'Text',
		'closetext':	'Text'
	}
});

/*
 *****************************************
 * VIEWS
 *****************************************
 */
 var NewsView = Backbone.View.extend({
	events: {
		'click footer.footer_close, header.cell_title': 'toggleOpen'
	},
	initialize: function() {
		this.model.bind('change:opened', this.updateDisplayState, this);
	},
	toggleOpen: function(e) {
		e.preventDefault();
		window.feedRouter.navigate((this.model.get('opened'))? '/' : '/nyheder/' + this.model.get('slug'), true);
	},
	updateDisplayState: function() {
		var opened = this.model.get('opened');
		$(this.el).toggleClass('current', opened);
		this.$('.toggler.open').text((opened)? this.model.get('closetext') : this.model.get('opentext'));
	},
	render: function() {
		return this;
	}
});

 var InfoView = Backbone.View.extend({
	events: {
		'click footer.footer_close, header.cell_title': 'toggleOpen'
	},
	initialize: function() {
		this.model.bind('change:opened', this.updateDisplayState, this);
	},
	toggleOpen: function(e) {
		e.preventDefault();
		window.feedRouter.navigate((this.model.get('opened'))? '/' : '/information/' + this.model.get('slug'), true);
	},
	updateDisplayState: function() {
		var opened = this.model.get('opened');
		$(this.el)
			.toggleClass('current small-long', opened)
			.toggleClass('iso_small_style', !opened);
		this.$('.toggler.open').text((opened)? this.model.get('closetext') : this.model.get('opentext'));
	},
	render: function() {
		return this;
	}
});

var ArtistView = Backbone.View.extend({
	events: {
		'click footer.footer_close, header.cell_title': 'toggleOpen',
		'click .footer_close .toggler.like': 'toggleLike',
		'click .artist-meta .like': 'toggleLike'
	},
	initialize: function() {
		this.model.bind('change:likedByUser', this.updateLike, this);
		this.model.bind('change:likes', this.updateLikeCount, this);
		this.model.bind('change:opened', this.updateDisplayState, this);
		this.meta = new ArtistMetaView({model: this.model});
		this.meta.bind('toggleLike', this.toggleLike, this);
		
		this.commentsController = new CommentsController();
		
		$(this.el).toggleClass('liked', this.model.get('likedByUser'));
	},
	toggleOpen: function(e) {
		e.preventDefault();
		window.feedRouter.navigate((this.model.get('opened'))? '/' : '/system/' + this.model.get('slug'), true);
	},
	toggleLike: function(e) {
		var id = this.model.get('id'), 
			lc = window.likesController;
		
		(lc.hasLike(id))? lc.removeLike(id) : lc.addLike(id);
		
		this.model.set({likedByUser: lc.hasLike(id)});
		return false;
	},
	updateDisplayState: function() {
		var layout 		= this.model.get('layout'),
			resizeTo	= 'big-square',
			opened 		= this.model.get('opened');
		
		
		if(this.model.get('resizeto')) resizeTo = this.model.get('resizeto');
				
		if (this.model.get('opened')) {
			if (layout == 'small-square' || layout == 'small-long') {
				
				var self = this;
				$(this.el).removeClass(layout).addClass(resizeTo).css({
					'background-image': 'url(' + self.model.get('bigimg') + ')'
				});
			}
			this.$('.post_content').append(this.meta.render().el);
			this.commentsController.init('#post-' + this.model.get('id') + ' .fb-comments');
		} else {
			if (layout == 'small-square' || layout == 'small-long') {
				
				var self = this;
				$(this.el).removeClass(resizeTo).addClass(layout).css({
					'background-image': 'url(' + self.model.get('normalimg') + ')'
				});
			}
			this.meta.remove();
		}
		
		$(this.el).toggleClass('current', this.model.get('opened'));
		this.$('.toggler.open').text((opened)? this.model.get('closetext') : this.model.get('opentext'));
	},
	updateLike: function() {
		var liked 	= this.model.get('likedByUser'),
			count	= parseInt(this.model.get('likes'));
		
		if (isNaN(count)) count = 0; 
		
		(liked)? count++ : count--;
		
		this.model.set({likes: count});
		$(this.el).toggleClass('liked', liked);
		window.isotopeController.filter(window.isotopeController.currFilter);
	},
	updateLikeCount: function() {
		var likes = this.model.get('likes');
		this.$('.footer_close .count').text(likes);
	},
	render: function() {
		return this;
	}
});


 
/*
 *****************************************
 * Collections
 *****************************************
 */
var NewsCollection = Backbone.Collection.extend({ 
	showItem: function(term) {
		for (var i = 0; i < this.models.length; i++) {
			var model = this.models[i];
			model.set({ opened: (model.get('slug') == term) });
		}
	},
	hideAll: function() {
		for (var i in this.models) {
			this.models[i].set({opened: false});
		}
	}
});
	
var ArtistCollection = Backbone.Collection.extend({
	showItem: function(term) {
		for (var i = 0; i < this.models.length; i++) {
			var model = this.models[i];
			model.set({ opened: (model.get('slug') == term) });
		}
	},
	hideAll: function() {
		for (var i in this.models) {
			this.models[i].set({opened: false});
		}
	}
});

/*
 *****************************************
 * Controllers
 *****************************************
 */
 
/*
 * USER LIKES CONTROLLER
 * This controller handles add/remove of artist likes as well 
 * as fetching previous likes form HTML5 localStorage object.
 * 
 * Likes are based on ID's from the wordpress database
 */
var UserLikesController = function() {
	this.likes 	= new Array();
	
	var dilimiter 	= '|||',
		key			= 'likedArtists',
		self		= this,
		hasLS		= Modernizr.localstorage;
		
	
	this.fetchLikes = function() {
		if (hasLS && localStorage.getItem(key)) {
			self.likes = localStorage.getItem(key).split(dilimiter);
		} else log('Item ' + key + ' not found in localStorage… no worries, we\'ll just create it');
		
		return self.likes;
	}
	
	this.addLike = function(id) {
		if (!inArray(self.likes, id)) {
			self.likes.push(id);
			updateLikes();
			postToServer(id, true);
			
			if (hasLS && localStorage.getItem('notifiedOfLikesystem') != 'yes' && self.likes.length < 2) {
				if ($('#').length > 0 || $('#post-12').length > 0) {
					// artists page or program page
					growlController.growl("Etiam porta sem malesuada magna mollis euismod.", true, "Ligula");
				} else {
					// Not artist or program page
					growlController.growl("Etiam porta sem malesuada magna mollis euismod.", true, "Ligula");
				}
				
				localStorage.setItem('notifiedOfLikesystem', 'yes');
			}
		}
	}
	
	this.removeLike = function(id) {
		var index = inArray(self.likes, id, true);
		if (index !== false) {
			self.likes.splice(index, 1);
			updateLikes();
			postToServer(id, false);
		}
	}
	
	this.hasLike = function(id) {
		if (inArray(self.likes, id)) return true; 
		else return false;
	}
	
	function updateLikes() {
		if (!hasLS) return false;
		localStorage.setItem(key, self.likes.join(dilimiter));
	}
	

	
	// Returns index/true if value exists within array. Otherwise false.
	function inArray(arr, val, returnIndex) {
		for (var i = 0; i < arr.length; i++) {
			if (arr[i] == val) return (returnIndex)? i : true;
		}
		
		return false;
	}
}
 
var IsotopeController = function() {
	var layoutMode 	= 'masonry',
		$iso		= false,
		animating	= false,
		onlyFav		= false,
		currFilter	= '',
		self		= this;
	
	this.container = false;
	this.itemSelector = false;
	
	this.init = function() {
		if (self.itemSelector && self.container) {
			$iso = $(self.container);
			$iso.isotope({
				itemSelector: self.itemSelector,
				animationEngine: $.browser.mozilla? 'jquery' : 'best-available', // Firefox can't calculate offset() properly with transforms applied.
				layoutMode: 'masonry',
				masonry: {
					columnWidth: 240
				},
				getSortData : {
					timestamp : function ( $elem ) {
						return parseInt($elem.data('timestamp'));
					},
					cell_title : function ($elem) {
						return $elem.data('cell_title');
					},
					likes : function ($elem) {
						return parseInt($elem.data('likes'));
					}
				}
			});
		} else throw new Error('IsotopeController: init() > items or container wasn\'t defined…')
	}
		
	this.filter = function(value) {
		if ($iso) {
			self.currFilter = value;
			
			// Check if we have a second filter
			
			
			// Check if we only want favorites.
			if (self.onlyFav && value) value += '.liked'; // Filter applied and favorites toggled on.
			else if (self.onlyFav && !value) value = '.liked'; // No filter and favorites toggled on.
			else if (!self.onlyFav && !value) value = '*'; // No filter and favorites toggled off.
			
			$iso.isotope({filter: value});
		}
	}
	
	this.sort = function(value) {
		if ($iso) {
			$iso.isotope({ 
				sortBy : value, 
				sortAscending: (value == 'cell_title')
			});
		}
	}
	
	this.setOnlyFav = function(value) {
		if (self.onlyFav == value) return false;
		self.onlyFav = value;
		self.filter(self.currFilter);
	}
	
	this.updateLayout = function(doScroll) {
		self.animating = true;
		if ($iso) $iso.isotope('reLayout', function() {
			
			// For some reason isotope fires this callback three times. Let's work around that.
			if (self.animating && document.location.hash.length > 5 && doScroll != false) {
				var $target = $('.iso_selector.current');
				setTimeout(function() {
					var easing = 'easeInOutCubic';
					if (Modernizr.localstorage && localStorage.getItem('funkyMode') == 'yes') easing = 'easeOutElastic';
					$.scrollTo($target, 900, {easing: easing, axis: 'y', offset: {top: -50}});
				}, 500);
			}
			
			self.animating = false;
		});
	}
}

var Toggle = function(selector, parentSelector, hijackEvent, switchMode, onSelect) {
	this.$items = false;
	this.$containers = false;
	var self = this;
	
	this.init = function() {
		self.$items = $(selector);
		self.$containers = self.$items.parents(parentSelector);
		self.$items.each(function() {
			$(this).data('container', $(this).parents(parentSelector));
		});
		
		self.$items.click(function(e) { 
			if (hijackEvent) e.preventDefault();
			
			if (switchMode) {
				self.$containers.removeClass('current');
				$(this).data('container').addClass('current');
			}
			else {
				$(this).data('container').toggleClass('current');
			}
			
			if (onSelect) onSelect($(this));
		});
	};
	
	this.getCurrent = function() {
		return self.$containers.filter('.current').find('a');
	}
	
	return this;
}

var GrowlController = function() {
	var iconURL 		= '',
		defaultOptions 	= { sticky: false, icon: iconURL, duration: 5000, cell_title: 'Aenean:' } 
	
	this.growl = function(message, sticky, cell_title) {
		var options = defaultOptions;
		options.message = message;
		if (sticky) options.sticky = sticky;
		if (cell_title) options.cell_title = cell_title;
		
		$.meow(options);
	}
}

var AjaxLinkController = function() {
	var $links 			= false,
		$container		= false,
		linkSelector	= '',
		self			= this;
	
	var btnIsCurrent = function($btn) {
		return $container.find($btn.data('targetel')).length;
	}

	this.init = function(selector) {
		linkSelector = selector;
		self.refreshLinks();
		
		if ($links.length < 1) return false;
		
		$container = $('<div id="ajax-container" class="awaiting-ajax-content"></div>');
		$('.iso_container:first').prepend($container);
		$container.slideUp(0);
		
		$('#content').on('click', selector, function(e) {
			e.preventDefault();
			var target 		= '',
				$btn		= $(this),
				href		= $(this).attr('href'),
				targetEl	= $(this).data('targetel');
				
			if ($btn.data('opened')) {
				self.closeAjaxContent();
				return false;
			}
			

			target = href + ' ' + targetEl;
			self.loadStuff(target);
		});
	}

	this.loadStuff = function(target) {
		$container
			.removeClass('awaiting-ajax-content')
			.load(target, function() {
				$container.stop(true, true).slideDown(1000, 'easeOutBounce');
				
				// Map clicks on #close-schedule link to close button
				$('#close-schedule').click(function(e) { 
					e.preventDefault(); // <-- Find a better way to simulate button click.
					self.closeAjaxContent();
				});

				$('.scene a').on('click', function() {
					try {
						var $dayFilter 		= $('nav.filter.one li:first-child a'),
							$sceneFilter	= $('nav.filter.two li:first-child a'),
							$favFilter		= $('nav.switch a'),
							filters			= [$dayFilter, $sceneFilter, $favFilter];
						
						if (!$dayFilter.parent().hasClass('current')) $dayFilter.click();
						if (!$sceneFilter.parent().hasClass('current')) $sceneFilter.click();
						if ($favFilter.parent().hasClass('current')) $favFilter.click();
					}catch(err) {
						log('Error unsetting filter: ' + err);
					}
				});

				self.updateBtns();
			});

	}

	this.updateBtns = function() {
		// If ajax container has content find the associated button and update its text to closed-text value.
		if ($container) {
			if (!$container.hasClass('awaiting-ajax-content')) {
				$links.each(function() {
					var $btn = $(this);
					
					if (btnIsCurrent($btn)) {
						$btn.html($btn.data('close-text')).data('opened', true);
					} else {
						$btn.html($btn.data('open-text'));
					}
						
				});
			} 

			// Else set all link texts to closed-text value.
			else {
				$links.each(function() {
					$(this).html($(this).data('open-text')).data('opened', false);
				});
			}
		}
	}

	this.closeAjaxContent = function() {
		$container.addClass('awaiting-ajax-content').stop(true, true).slideUp(800, 'easeInOutQuart');
		$links.data('opened', false);
		self.refreshLinks();
	}

	this.refreshLinks = function() {
		if (linkSelector) $links = $(linkSelector);
		if ($links.length) this.updateBtns();
	}
}

var SidebarController = function() {
	var $sidebar 	= $('#main-sidebar'),
		sidebarHTML	= false,
		$body		= $('body'),
		watch		= false,
		self		= this;

	this.removed = false;
	
	this.start = function() {
		watch = true;
		this.watchBrowserSize();
	}
	
	this.stop = function() { 
		watch = false;
	}
	
	this.watchBrowserSize = function() {
		var sbcontroller = this;
		
		var w = window.innerWidth;
		if (w < 1000) {
			if (!this.removed) {
				if (!sidebarHTML) sidebarHTML = $sidebar.html();
					
				$sidebar.find('.inner-sidebar').remove();
				this.removed = true;
			} 
		} else {
			if (this.removed) { 
				$sidebar.append(sidebarHTML); 
				this.removed = false;
				window.ajaxLinks.refreshLinks();
			}
		}
		
		if (watch) {
			setTimeout(function() {
				sbcontroller.watchBrowserSize();
			}, 1000);
		}
	}
}

var CommentsController = function() {
	var $comments 	= false,
		height		= 0,
		oldHeight	= 0,
		self 		= this;
		
	this.init = function(selector) {
		$comments = $(selector);
		
		setTimeout(function() {
			FB.XFBML.parse();
		}, 1500);
		
		watchHeight(function() {
			isotopeController.updateLayout(false);
		});
	}
	
	function watchHeight(callback) {
		setTimeout(function() {
			height = $comments.height();
			if (height != oldHeight && height > 160) callback();
			oldHeight = height;
			watchHeight(callback);
		}, 1000);
	}
}

/*
 *****************************************
 * ROUTERS
 *****************************************
 */
var FeedRouter = Backbone.Router.extend({
	routes: {
		'/':						'root',
		//'/system/:term': 	'showArtist',
		//'/nyheder/:term': 		'showNewsItem',
		'/information/:term': 	'showInfoItem'
	},
	initialize: function() {
		this.news		= new NewsCollection();
		this.artists 	= new ArtistCollection();
		this.info		= new NewsCollection();
	},
	root: function() {
		this.news.hideAll();
		this.artists.hideAll();
		this.info.hideAll();
		this.updateLayout();
	},
	showInfoItem: function(term) {
		this.info.showItem(term);
		this.updateLayout();
	},
	updateLayout: function() {
		window.isotopeController.updateLayout();
	}
});

/*
 *****************************************
 *****************************************
 */
$(function() {
	window.likesController = new UserLikesController();
	window.isotopeController = new IsotopeController();
	window.feedRouter = new FeedRouter();
	window.growlController = new GrowlController();
	window.ajaxLinks = new AjaxLinkController();
	
	// Fetch likes from HTML5 Local Storage
	window.likesController.fetchLikes();
	
	// Detect ajaxified links
	ajaxLinks.init('a.ajax-link');
	
	// Set up isotope
	window.isotopeController.container = '.iso_container > .items';
	window.isotopeController.itemSelector = '.iso_selector';
	window.isotopeController.init();
	
	// Filters, Switches and sorting
	var filterToggle		= new Toggle('nav.filter.one a', 'li', true, true, onFilterToggle),
		secondFilterToggle	= new Toggle('nav.filter.two a', 'li', true, true, onFilterToggle),
		sortToggle			= new Toggle('nav.sort a', 'li', true, true, onSortToggle).init(),
		favToggle			= new Toggle('nav.switch a', 'div.toggle', true, false, onFavToggle).init();
		sidebarController	= new SidebarController();
	
	if (!navigator.userAgent.match(/iPhone/i)) sidebarController.start();
	
	filterToggle.init();
	secondFilterToggle.init();
	if (secondFilterToggle.$items.length < 1) secondFilterToggle = false;
	
	function onSortToggle($el) { window.isotopeController.sort($el.data('sort')); }
	
	function onFilterToggle($el) { 
		if (secondFilterToggle) {
			var firstFilter 	= filterToggle.getCurrent().data('filter'),
				secondFilter 	= secondFilterToggle.getCurrent().data('filter'),
				combinedFilter	= firstFilter + secondFilter;
				
			// catch ** filter and convert it to *
			if (combinedFilter == '**') combinedFilter = '*';
			
			window.isotopeController.filter(combinedFilter);
		} else {
			window.isotopeController.filter($el.data('filter'));
		}
		 
	}
	
	function onFavToggle($el) {
		var result = ($el.parents('div.toggle').hasClass('current'));
		window.isotopeController.setOnlyFav(result);
	}
	
	
	/*
	 * Detect and activiate initially selected filter.
	 */
	filterToggle.getCurrent().click();
	
	/*
	 * No LocalStorage? Remove favorites filter..
	 */
	if (!Modernizr.localstorage) $('nav.switch').remove();
	
	/*
	 * Animate in pages
	 */
	var $posts = $('.iso_selector');
	$posts.each(function() {
		var $article = $(this);
		setTimeout(function() {
			$article.css({'opacity': 1});
		}, Math.random() * 650)
	});
	
	
	/*
	 * Add items to InfoCollection
	 */
	$('.type-information').each(function() {
		var $el	= $(this),
			m 	= new NewsModel(),
			v 	= new InfoView({model: new NewsModel(), el: $(this)[0], router: window.feedRouter});
		
		v.model.set({ 
			id: 		$el.data('id'), 
			cell_title: 		$el.data('cell_title'), 
			slug: 		$el.data('slug'),
			opentext: 	'mere',
			closetext: 	'luk'
		});
		window.feedRouter.info.add(v.model);
	});
	
	/*
	 * URL Rewriting
	 */
	Backbone.history.start({pushState: false});
});

/*
 * Fix iOS scale bug on iPad 
 */
if (navigator.userAgent.match(/iPad/i)) {
   (function() {
	
		var metas = document.querySelectorAll('meta[name="viewport"]'),
		    forEach = [].forEach;
	
		function fixMetas(firstTime) {
			forEach.call(metas, function(el) {
				el.content = firstTime
					? 'width=device-width,minimum-scale=1.0,maximum-scale=1.0'
					: 'width=device-width,minimum-scale=0.25,maximum-scale=1.6';
			});
		}
	
		fixMetas(true);
	
		document.body.addEventListener('gesturestart', fixMetas, false);
	
	}());
}

