﻿/// <reference path="../Scripts/jquery-1.8.2.js" />
/// <reference path="jquery.isotope.min.js" />


$(function () {
    // Globals
    var TABSET2_DEFAULT_HEIGHT = 130;

    $('.items').isotope({
        getSortData: {
            name: function ($elem) {
                return $elem.find('h3').text();
            },
        }
    });
    $('.items').isotope({ itemSelector: 'article', layoutMode: 'masonry', masonry: { columnWidth: 240 } });

    $('.systems_sub_filter_wrapper .see_more a').click(function () {
        if ($(this).hasClass('see_more_down')) {
            addSubhashValue('details');
        }
        else {
            removeSubhashValue('details');
        }
        return false;
    });

    $('.iso_item').click(function () {
        updateSelectedItem($(this));
        return false;
    });

    $('.systems_filter_container a').click(function () {
        if ($(this).attr('href') == '#/' + getHashSlashValues().value1) {
            setHashValues('all');
            return false;
        }
        return true;
    });

    $('.systems_sub_filter_navigation a').click(function () {
        if ($(this).attr('href') == '#/' + getHashSlashValues().value1) {
            $('#' + $(this).attr('rel')).slideToggle('slow');
            return false;
        }
        return true;
    });

    function updateSelectedItem($item) {
        var itemId = $item.attr('data-slug');
        var hashValues = getHashSlashValues();
        if (itemId == hashValues.value2) { // Second click to same item to close.
            hashValues.value2 = '';
        }
        else {
            hashValues.value2 = itemId;
        }
        removeSubhashValue('scroll',hashValues.value1, hashValues.value2);
    }

    $(window).bind('hashchange', function (e) {
        var infoFromHash = getInfoFromHash();
        // Minimize any currently selected items.
        $('.items article.current').addClass('iso_small_style').removeClass('current small-long');
        // Show newly selected item.
        if (infoFromHash.selectedItem != '') {
            $('article[data-slug="' + infoFromHash.selectedItem + '"]').removeClass('iso_small_style').addClass('current small-long');
        }
            // Remove scroll hash value if present and return page.
        else if (infoFromHash.scrollToSelectedItem) {
            removeSubhashValue('scroll', infoFromHash.category, infoFromHash.selectedItem);
            return;
        }
        // Tabset navigation.
        var newlySelectedTabset = new tabset(infoFromHash.tabSelector, infoFromHash.category);
        var otherTabset = new tabset(infoFromHash.otherTabSelector, null);
        // Used as callback for case changing within same tab group and for first tab selection.
        var detailsFunction = function () {
            if (newlySelectedTabset.isTabRow2) {
                var detailsLinkObj = $(newlySelectedTabset.getNewContentObj()).find('.see_more a');
                var contentTextObj = $(newlySelectedTabset.getNewContentObj()).find('.systems_tabs_overviewtext');
                showDetails(detailsLinkObj, contentTextObj, infoFromHash);
            }
        }

        // Case changing tab selection within the same tab group.
        if (newlySelectedTabset.selectedTabObj.length > 0) {
            // Case no change, same tab selected.
            if (newlySelectedTabset.selectedTabHref == '#/' + newlySelectedTabset.newCategory) {
                detailsFunction();
            }
            else {
                var selectNewTabFunction = function () {
                        if (infoFromHash.isTabRow2) {
                            if (newlySelectedTabset.getSelectedContentObj().css('display') == 'none') {
                                newlySelectedTabset.getNewContentObj().slideDown('slow');
                            }
                            else {
                                var fadeCallback = function () {
                                    newlySelectedTabset.getNewContentObj().find('.systems_sub_filter_copy_container').fadeTo(0, 0);
                                    newlySelectedTabset.getSelectedContentObj().hide();
                                    newlySelectedTabset.getSelectedContentObj().find('.systems_sub_filter_copy_container').fadeTo(0, 1);
                                    newlySelectedTabset.getNewContentObj().show();
                                    newlySelectedTabset.getNewContentObj().find('.systems_sub_filter_copy_container').fadeTo('slow', 1);
                                }
                                newlySelectedTabset.getSelectedContentObj().find('.systems_sub_filter_copy_container').fadeTo('fast', 0, fadeCallback);
                            }
                        }
                        else {
                            var fadeCallback2 = function () {
                                newlySelectedTabset.getNewContentObj().find('.systems_text_container').fadeTo(0, 0.25);
                                newlySelectedTabset.getSelectedContentObj().hide();
                                newlySelectedTabset.getSelectedContentObj().find('.systems_text_container').fadeTo(0, 1);
                                newlySelectedTabset.getNewContentObj().show();
                                newlySelectedTabset.getNewContentObj().find('.systems_text_container').fadeTo('slow', 1);
                            }
                            newlySelectedTabset.getSelectedContentObj().find('.systems_text_container').fadeTo('fast', 0.25, fadeCallback2);
                        }
                    newlySelectedTabset.selectNewTab(false);
                }
                newlySelectedTabset.deselectTab(false, selectNewTabFunction);
            }
        }
            // Case changing tab selection to a different tab group.
        else if (otherTabset.selectedTabObj.length > 0) {


            var selectNewTabFunction2 = function () {
                newlySelectedTabset.selectNewTab(true);
                if (infoFromHash.isTabRow2) {
                    otherTabset.getSelectedContentObj().slideUp('slow', function () { otherTabset.getTabsetTextContainerObj().fadeOut(300); });
                    newlySelectedTabset.getNewContentObj().slideDown('slow');
                }
                else {
                    newlySelectedTabset.getTabsetTextContainerObj().fadeIn(300, function () { newlySelectedTabset.getNewContentObj().slideDown('slow'); });
                    otherTabset.getSelectedContentObj().slideUp('slow');
                }
            }
            otherTabset.deselectTab(true, selectNewTabFunction2);
        }
            // Case selecting tab when none selected before.
        else {
            if (infoFromHash.isTabRow2) {
                newlySelectedTabset.getNewContentObj().slideDown('slow', detailsFunction);
            }
            else {
                newlySelectedTabset.getTabsetTextContainerObj().fadeIn(300, function () { newlySelectedTabset.getNewContentObj().slideDown('slow'); });
            }
            newlySelectedTabset.selectNewTab(true);
        }
        // Filter and sort isotope items.
        $('.items').isotope({ filter: infoFromHash.filter });
        $('.items').isotope({ sortBy: infoFromHash.sort });
        $('.items').isotope('reLayout');
        // Scroll window if scroll hash value set.
        if (infoFromHash.selectedItem != '' && infoFromHash.scrollToSelectedItem) {
            if (newlySelectedTabset.isTabRow2) {
                $('html, body').animate({ scrollTop: $('.systems_sub_filter_wrapper').offset().top - 25 }, 1500);
            }
            else {
                $('html, body').animate({ scrollTop: $('article[data-slug="' + infoFromHash.selectedItem + '"]').offset().top - 70 }, 1500);
            }
        }
    });

    function showDetails(detailsLinkObj, contentTextObj, infoFromHash) {
        detailsLinkObj = $(detailsLinkObj);
        contentTextObj = $(contentTextObj);
        if (infoFromHash.displayDetails) {
            var origHeight = contentTextObj.height();
            contentTextObj.height('auto');
            var fullHeight = contentTextObj.height();
            contentTextObj.height(origHeight + 'px');
            contentTextObj.animate({ height: fullHeight + 'px' }, 600);
            detailsLinkObj.addClass('see_less_up').removeClass('see_more_down');
        }
        else {
            if (detailsLinkObj.hasClass('see_less_up')) {
                contentTextObj.animate({ height: TABSET2_DEFAULT_HEIGHT + 'px' }, 600);
            }
            detailsLinkObj.addClass('see_more_down').removeClass('see_less_up');
        }
    }

    function tabset(tabsetContainerSelector, newCategory) {
        thisObj = this;
        this.tabsetContainerSelector = tabsetContainerSelector;
        this.isTabRow2 = (this.tabsetContainerSelector == '.systems_sub_filter_wrapper');
        this.newCategory = newCategory;
        this.selectedTabObj = $(tabsetContainerSelector + ' a.selected');
        this.selectedTabHref = this.selectedTabObj.attr('href');
        this.isSelected = this.selectedTabObj.length > 0;
        this.getSelectedContentObj = function () { return $('#' + this.selectedTabObj.attr('rel')); };
        this.getSelectedContentOverviewTextObj = function () { return $(this.getSelectedContentObj()).find('.systems_tabs_overviewtext'); }
        this.getNewTabObj = function () { return $(this.tabsetContainerSelector + ' a[href="#/' + this.newCategory + '"]'); };
        this.getTabsetTextContainerObj = function () { return $('.systems_text_container'); };
        this.deselectTab = function (changeingTableRow, callbackFunction) {
            // Hide extra tab info on leaving the tab, only for second tab row.
            if (this.isTabRow2) {
                $(this.getSelectedContentOverviewTextObj()).animate({ height: TABSET2_DEFAULT_HEIGHT + 'px' }, 'medium', callbackFunction);
                $('.systems_sub_filter_wrapper .see_less_up').toggleClass('see_less_up see_more_down'); //to look into
            }
            else {
                callbackFunction();
            }
            // Deselect.
            this.selectedTabObj.toggleClass('selected', false);
        };
        this.selectNewTab = function (changingTabRow) {
            if (changingTabRow) {
                if (this.isTabRow2) {
                    $('.sub_tabs_filter').slideDown('medium', function () { $(this).fadeTo('medium', 1) });
                }
                else {
                    $('.sub_tabs_filter').fadeTo('medium', 0, function () { $(this).slideUp('medium') });
                }
            }
            if (this.isTabRow2) {
                $('.systems_filter_container .nav_deactivated').removeClass('nav_deactivated');
            }
            else {
                $('.systems_filter_container a').addClass('nav_deactivated');
            }
            this.getNewTabObj().addClass('selected').removeClass('nav_deactivated');
        };
        this.getNewContentObj = function () { return $('#' + this.getNewTabObj().attr('rel')); };
    }

    $(window).trigger('hashchange');

    function getInfoFromHash() {
        var filter;
        var sort = 'original-order';
        var isTabRow2 = false;
        var tabSelector = '';
        var hashValues = getHashSlashValues();
        switch (hashValues.value1) {
            case 'all':
            case '':
                filter = '*';
                sort = 'name';
                tabSelector = '.systems_sub_filter_wrapper';
                isTabRow2 = true;
                hashValues.value1 = 'all';
                break;
            case 'it':
                filter = '.support, .sbx, .tournament_manager';
                tabSelector = '.systems_filter_wrapper';
                break;
            case 'gaming_ops':
                filter = '.support, .tournament_manager';
                tabSelector = '.systems_filter_wrapper';
                break;
            case 'finance':
                filter = '.advantage, .sbx, .tournament_manager';
                tabSelector = '.systems_filter_wrapper';
                break;
            case 'marketing':
                filter = '.service_window, .advantage';
                tabSelector = '.systems_filter_wrapper';
                break;
            default:
                filter = '.' + hashValues.value1;
                tabSelector = '.systems_sub_filter_wrapper';
                isTabRow2 = true;
                break;
        }
        var otherTabSelector = (tabSelector == '.systems_sub_filter_wrapper' ? '.systems_filter_wrapper' : '.systems_sub_filter_wrapper')
        return { isTabRow2: isTabRow2, tabSelector: tabSelector, otherTabSelector: otherTabSelector, category: hashValues.value1, filter: filter, sort: sort, selectedItem: hashValues.value2, scrollToSelectedItem: (hashValues.subhash.indexOf('scroll') != -1), displayDetails: (hashValues.subhash.indexOf('details') != -1) };
    }

    function HashInfo() {
        this.SCROLL_TOKEN = 'scroll';
        this.DETAILS_TOKEN = 'details';
        this.hash = new Hash();
        this.update = function myfunction() {
            this.hash.update();
           
        }
        this.getTopMenuValue = this.hash.getFirstValue;
        this.getCategory = this.hash.getSecondValue;
        this.getSelectedItem = this.hash.getThirdValue;
        this.isScroll = function () { return this.hash.containsSubhash(this.SCROLL_TOKEN) }
        this.isDetails = function () { return this.hash.containsSubhash(this.DETAILS_TOKEN) }
        
    }

    function Hash() {
        this.url = '';
        this.values = new Array();
        this.subhashs = new Array();
        this.getFirstValue = function () { if (this.values.length > 1) { return this.values[1]; } else { return ''; } };
        this.getSecondValue = function () { if (this.values.length > 2) { return this.values[2]; } else { return ''; } };
        this.getThirdValue = function () { if (this.values.length > 3) { return this.values[3]; } else { return ''; } };
        this.containsSubhash = function (value) { return (this.subhashs.indexOf(value.toLowerCase()) != -1) };
        this.getValueString = function () { return this.values.join('/') }
        this.getSubhashString = function () { return this.subhashs.join(',') }
        this.getHashString = function () {
            if (this.values.length < 2) { return; }
            var hashs = [this.getValueString()];
            if (this.subhashs.length > 0) { hashs[1] = this.getSubhashString() }
            return '#' + hashs.join('#');
        }
        this.update = function (optionalNewUrl) {
            if (arguments.length == 0) {
                this.url = new String(window.location);
            }
            else {
                this.url = optionalNewUrl;
            }
            var hashs = this.url.split('#');
            if (hashs.length < 2) { this.values = []; this.subhashs = []; return; }
            this.values = hashs[1].split('/');
            if (hashs.length < 3) { this.subhashs = []; return; }
            this.subhashs = hashs[2].split(',');
        }
        this.update();
        this.setHash = function () {
            window.location = this.getHashString();
        }
        this.changeSingleValue = function (valueNumberToChange, newValue) {
            this.values[indexOfValueToChange] = newValue;
        }
        this.addSubhashItem = function (newItem) {
            if (this.containsSubhash(newItem)) { return; }
            this.subhashs[this.subhashs.length] = newItem;
        }
        this.removeSubhashItem = function (itemToRemove) {
            if (!this.containsSubhash(itemToRemove)) { return; }
            var newSubhashItems = [];
        $.each(this.subhashs, function (index, item) { if (item != itemToRemove) { newSubhash[newSubhash.length] = item } });
        }
    }

    function getHashSlashValues() {
        var val1 = '';
        var val2 = '';
        var subhash = [];
        var url = new String(window.location).toLowerCase();
        var hashs = url.split("#");
        if (url.indexOf("#/") != -1) {
            var segments = hashs[1].split("/");
            if (segments.length > 1) {
                val1 = segments[1];
                if (segments.length > 2) {
                    val2 = segments[2];
                }
                if (segments.length > 3) {
                    val3 = segments[3];
                }
            }
            if (hashs.length > 2) {
                subhash = hashs[2].split(',');
            }
        }
        if (val2 === undefined || val2 === null) {
            val2 = '';
        }
        return { value1: val1, value2: val2, subhash: subhash };
    }

    function setHashValues(value1, value2, subhash) {
        if (!value1) {
            value1 = 'all';
        }
        var values = '#/' + value1;
        if (value2 === undefined || value2 === null) {
            value2 = '';
        }
        if (value2 != '') {
            values += "/" + value2;
        }
        if (subhash && subhash.length != 0 && ((subhash.length == 1 && subhash[0] != '') || (subhash.length > 1))) {
            values += "#" + subhash.join(',');
        }
        window.location = values;
    }

    function removeSubhashValue(value, optionalSlashValue1, optionalSlashValue2) {
        var values = getHashSlashValues();
        var newSubhash = [];
        $.each(values.subhash, function (index, item) { if (item != value) { newSubhash[newSubhash.length] = item } });
        if (optionalSlashValue1 != undefined && optionalSlashValue1 != null) {
            values.value1 = optionalSlashValue1;
        }
        if (optionalSlashValue2 != undefined && optionalSlashValue2 != null) {
            values.value2 = optionalSlashValue2;
        }
        setHashValues(values.value1, values.value2, newSubhash);
    }

    function addSubhashValue(value, optionalSlashValue1, optionalSlashValue2) {
        var values = getHashSlashValues();
        if (values.subhash.indexOf(value) == -1) {
            values.subhash[values.subhash.length] = value;
        }
        if (optionalSlashValue1 != undefined && optionalSlashValue1 != null) {
            values.value1 = optionalSlashValue1;
        }
        if (optionalSlashValue2 != undefined && optionalSlashValue2 != null) {
            values.value2 = optionalSlashValue2;
        }
        setHashValues(values.value1, values.value2, values.subhash);
    }
});

