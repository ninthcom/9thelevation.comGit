﻿/// <reference path="../Scripts/jquery-1.8.2.js" />
/// <reference path="isotope.js" />

// Tab functionality.

function TabsetGroup(options) {
    // Fields.
    this.tabsets = new Array();
    this.tabsetGroupOptions = new Object();
    this.tabsetGroupOptions.tabsetOptions = {};
    this.tabsetGroupOptions.tabsetGroupMemberSelector = '.sub_tabs';
    this.tabsetGroupOptions.extraContentDisplayedIndicatorClass = 'slideSign';
    this.tabsetGroupOptions.extraContentContainerSelector = '.systems_messaging_wrapper';
    // Methods.
    this.initializeTabsetGroup = function () {
        var tabsetGroupMemberObjs = $(this.tabsetGroupOptions.tabsetGroupMemberSelector);
        this.tabsets = new Array(tabsetGroupMemberObjs.length);
        for (var i = 0; i < tabsetGroupMemberObjs.length; i++) {
            this.tabsets[i] = new Tabset($(tabsetGroupMemberObjs[i]), this.tabsetGroupOptions.tabsetOptions);
        }
    }
    this.initializeTabsetGroup();
    this.getSelectedTab = function () {
        for (var i = 0; i < this.tabsets.length; i++) {
            var tab = this.tabsets[i].getSelectedTab();
            if (tab != false) {
                return tab;
            }
        }
        return false;
    }
    this.getTabByHref = function (href) {
        for (var i = 0; i < this.tabsets.length; i++) {
            var tab = this.tabsets[i].getTabByHref(href);
            if (tab != false) {
                return tab;
            }
        }
        return false;
    }
    this.changeSelectedTab = function (newTabBaseValue) {
        var currentSelection = this.getSelectedTab();
        var newSelection = this.getTabByHref('#/' + newTabBaseValue);
        if (currentSelection === newSelection) {
            return newSelection;
        }
        if (currentSelection == false) {
            newSelection.slideDownContent();
        }
        else {
            currentSelection.deselect();
            var followUpFunction = function () {
                if (currentSelection.tabset === newSelection.tabset && (currentSelection.tabContentObj && newSelection.tabContentObj)) {
                    currentSelection.hideContent();
                    newSelection.showContent();
                }
                else {
                    currentSelection.slideUpContent();
                    newSelection.slideDownContent();
                }
            }
            var extraContentAnchor = [];
            if (currentSelection.tabContentObj) {
                extraContentAnchor = currentSelection.tabContentObj.find('.' + this.tabsetGroupOptions.extraContentDisplayedIndicatorClass);
            }
            if (extraContentAnchor.length > 0) {
                extraContentAnchor.toggleClass(this.tabsetGroupOptions.extraContentDisplayedIndicatorClass, false);
                currentSelection.tabContentObj.find(this.tabsetGroupOptions.extraContentContainerSelector).slideUp(currentSelection.tabOptions.slideUpDuration, followUpFunction);
            }
            else {
                followUpFunction();
            }
        }
        newSelection.select();
        return newSelection;
    }
}

function Tabset(tabsetContainerObj, options) {
    // Fields.
    this.tabsetContainerObj = null;
    this.tabs = new Array();
    this.tabsetOptions = new Object();
    this.tabsetOptions.tabOptions = {};
    this.tabsetOptions.tabAnchorSelector = 'a';
    // Methods.
    this.initializeTabset = function (tabsetContainerObj) {
        this.tabsetContainerObj = tabsetContainerObj;
        var tabAnchorObjs = this.tabsetContainerObj.find(this.tabsetOptions.tabAnchorSelector);
        this.tabs = new Array(tabAnchorObjs.length);
        for (var i = 0; i < tabAnchorObjs.length; i++) {
            this.tabs[i] = new Tab(tabAnchorObjs[i], this, this.tabsetOptions.tabOptions);
        }
    }
    this.initializeTabset(tabsetContainerObj);
    this.getSelectedTab = function () {
        for (var i = 0; i < this.tabs.length; i++) {
            if (this.tabs[i].isSelected()) {
                return this.tabs[i];
            }
        }
        return false;
    }
    this.getTabByHref = function (href) {
        for (var i = 0; i < this.tabs.length; i++) {
            if (href == this.tabs[i].getTabAnchorHref()) {
                return this.tabs[i];
            }
        }
        return false;
    }
}

function Tab(tabAnchorObj, tabset, options) {
    // Fields.
    this.tabset = tabset
    this.tabAnchorObj = null;
    this.tabOptions = new Object();
    this.tabOptions.tabContentPointer = 'rel';
    this.tabOptions.dataFilterAttribute = 'data-filter';
    this.tabOptions.selectionIndicatorClass = 'selected';
    this.tabOptions.showDuration = 0;
    this.tabOptions.hideDuration = 0;
    this.tabOptions.slideDownDuration = 'slow';
    this.tabOptions.slideUpDuration = 'slow';
    this.tabOptions.tabsetWrapperSelector = '.tabset_wrapper';
    this.tabOptions.collapseNavClass = '.collapse_secondary_nav_wrapper';
    this.tabContentObj = null;
    // Methods.
    this.initializeTab = function (tabAnchorObj) {
        this.tabAnchorObj = $(tabAnchorObj);
        if (this.tabAnchorObj.attr(this.tabOptions.tabContentPointer)) {
            this.tabContentObj = $('#' + this.tabAnchorObj.attr(this.tabOptions.tabContentPointer));
        }
        else {
            this.tabContentObj = null;
        }
    }
    this.initializeTab(tabAnchorObj);
    this.getTabAnchorHref = function () { return this.tabAnchorObj.attr('href') }
    this.getTabAnchorDataFilter = function () { return this.tabAnchorObj.attr(this.tabOptions.dataFilterAttribute) }
    this.isSelected = function () { return this.tabAnchorObj.hasClass(this.tabOptions.selectionIndicatorClass); }
    this.select = function () { this.tabAnchorObj.toggleClass(this.tabOptions.selectionIndicatorClass, true); }
    this.deselect = function () { this.tabAnchorObj.toggleClass(this.tabOptions.selectionIndicatorClass, false); }
    this.showContent = function () { if (this.tabContentObj) { this.tabContentObj.show(this.tabOptions.showDuration); } }
    this.hideContent = function () { if (this.tabContentObj) { this.tabContentObj.hide(this.tabOptions.hideDuration); } }
    this.slideDownContent = function () { if (this.tabContentObj) { this.tabContentObj.slideDown(this.tabOptions.slideDownDuration); } }
    this.slideUpContent = function () { if (this.tabContentObj) { this.tabContentObj.slideUp(this.tabOptions.slideUpDuration); } }
}

// Hash functionality.

function SlashHash() {
    this.values = new Array();
    this.getValue1 = function () { if (this.values.length > 0) { return this.values[0]; } else { return ''; } };
    this.getValue2 = function () { if (this.values.length > 1) { return this.values[1]; } else { return ''; } };
    this.getValue3 = function () { if (this.values.length > 2) { return this.values[2]; } else { return ''; } };
    this.getHashString = function () { return '#/' + this.values.join('/'); }
    this.updateValues = function (optionalNewUrl) {
        if (arguments.length == 0) {
            this.url = new String(window.location);
        }
        else {
            this.url = optionalNewUrl;
        }
        var hashLocation = this.url.indexOf('#/');
        if (hashLocation == -1 || hashLocation == this.url.length + 1) {
            this.values.length = 0;
        }
        else {
            this.values = this.url.toLowerCase().slice(hashLocation + 2).split("/");
        }
    }
    this.updateValues();
    this.setHashValues = function (hashValuesArray) {
        this.values = hashValuesArray;
        window.location = this.getHashString();
    }
    this.changeSingleValue = function (indexOfValueToChange, newValue) {
        this.values[indexOfValueToChange] = newValue;
        this.setHashValues(this.values);
    }
}


// Isotope functionality.
function IsoItems(clickedObj, nameOfPrevious, nameOfNewlySelected) {
    this.clickedObj = null;
    this.previousObj = null;
    this.newlySelectedObj = null;
    this.initializeIsoItems = function () {
        this.clickedObj = (clickedObj ? $(clickedObj) : null);
        this.previousObj = (nameOfPrevious ? $(this.getSelectorByName(nameOfPrevious)) : null);
        this.newlySelectedObj = (nameOfNewlySelected ? $(this.getSelectorByName(nameOfNewlySelected)) : null);
    }
    this.openAndCloseIsoItems = function () {
        if (this.clickedObj) {
            var clickedName = this.getObjName(this.clickedObj);
            if (this.previousObj != null && clickedName == this.getObjName(this.previousObj)) {
                this.closeItem(this.clickedObj);
                return '';
            }
            this.closeItem(this.previousObj);
            return clickedName;
        }
        else {
            this.closeItem($('.items .current'));
            if (this.newlySelectedObj) {
                this.openItem(this.newlySelectedObj)
            }
        }
    }
    this.getObjName = function (obj) { return $(obj).attr('data-slug') }
    this.getSelectorByName = function (name) { return 'article[data-slug="' + name + '"]'; }
    this.openItem = function (item) { $(item).toggleClass('iso_small_style', false, 'slow').toggleClass('current small-long', true, 'slow'); }
    this.closeItem = function (item) { $(item).toggleClass('iso_small_style', true).toggleClass('current small-long', false); }
    this.initializeIsoItems();
}

// Isotope from hash and tabs functionality.
$(function () {
    // Function fields
    var slashHashObj = new SlashHash();


    $('.items').isotope({
        getSortData: {
            name: function ($elem) {
                return $elem.find('h3').text();
            },
        }
    });

    $('.items').isotope({ itemSelector: 'article', layoutMode: 'masonry', masonry: { columnWidth: 240 } });

    $(window).bind('hashchange', function () {
        slashHashObj.updateValues();
        if (slashHashObj.getValue1() == '') {
            slashHashObj.setHashValues(['all']);
            return;
        }
        var tabsets = new TabsetGroup({});
        var newTab = tabsets.changeSelectedTab(slashHashObj.getValue1());
        $('.items').isotope({ filter: newTab.getTabAnchorDataFilter() });
        $('.items').isotope({ sortBy: (slashHashObj.getValue1() == 'all' ? 'name' : 'original-order') });
        (new IsoItems(null, null, slashHashObj.getValue2())).openAndCloseIsoItems();
        $('.items').isotope('reLayout');
    });

    $(window).trigger('hashchange');

    $('.mySlideToggler').click(function () {
        $(this).parent().parent().find('.systems_messaging_wrapper').slideToggle('slow');
        $(this).toggleClass('slideSign');
        return false;
    });

    $('.iso_item').click(function () {
        var newSlashValue = (new IsoItems(this, slashHashObj.getValue2(), null)).openAndCloseIsoItems();
        slashHashObj.changeSingleValue(1, newSlashValue);
    })



});

